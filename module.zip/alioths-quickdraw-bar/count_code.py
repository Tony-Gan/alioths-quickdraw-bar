import os

def count_lines_of_code():
    target_extensions = {'.css', '.js', '.hbs'}
    ignore_dirs = {'node_modules', '.git', 'dist', '__pycache__', 'venv'}
    
    stats = {ext: {'files': 0, 'lines': 0} for ext in target_extensions}
    total_files = 0
    total_lines = 0

    print(f"{'Extension':<12} | {'Files':<10} | {'Lines':<10}")
    print("-" * 40)

    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in dirs if d not in ignore_dirs]
        
        for file in files:
            ext = os.path.splitext(file)[1].lower()
            if ext in target_extensions:
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        lines = sum(1 for line in f)
                        stats[ext]['files'] += 1
                        stats[ext]['lines'] += lines
                        total_files += 1
                        total_lines += lines
                except Exception as e:
                    print(f"Could not read {file_path}: {e}")

    for ext, data in sorted(stats.items(), key=lambda x: x[1]['lines'], reverse=True):
        if data['files'] > 0:
            print(f"{ext:<12} | {data['files']:<10} | {data['lines']:<10}")

    print("-" * 40)
    print(f"{'TOTAL':<12} | {total_files:<10} | {total_lines:<10}")

if __name__ == "__main__":
    count_lines_of_code()